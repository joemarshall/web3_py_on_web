__version_info__ = (0, 10, 6)
__version__ = ".".join("{0}".format(x) for x in __version_info__)
