colorspacious
=============

.. image:: https://travis-ci.org/njsmith/colorspacious.svg?branch=master
   :target: https://travis-ci.org/njsmith/colorspacious
   :alt: Automated test status

.. image:: https://codecov.io/gh/njsmith/colorspacious/branch/master/graph/badge.svg
   :target: https://codecov.io/gh/njsmith/colorspacious
   :alt: Test coverage

.. image:: https://readthedocs.org/projects/colorspacious/badge/?version=latest
   :target: http://colorspacious.readthedocs.io/en/latest/?badge=latest
   :alt: Documentation Status

.. image:: https://zenodo.org/badge/38525000.svg
   :target: https://zenodo.org/badge/latestdoi/38525000

Colorspacious is a powerful, accurate, and easy-to-use library for
performing colorspace conversions.

In addition to the most common standard colorspaces (sRGB, XYZ, xyY,
CIELab, CIELCh), we also include: color vision deficiency ("color
blindness") simulations using the approach of Machado et al (2009); a
complete implementation of `CIECAM02
<https://en.wikipedia.org/wiki/CIECAM02>`_; and the perceptually
uniform CAM02-UCS / CAM02-LCD / CAM02-SCD spaces proposed by Luo et al
(2006).

To get started, simply write::

  from colorspacious import cspace_convert

  Jp, ap, bp = cspace_convert([64, 128, 255], "sRGB255", "CAM02-UCS")

This converts an sRGB value (represented as integers between 0-255) to
CAM02-UCS `J'a'b'` coordinates (assuming standard sRGB viewing
conditions by default). This requires passing through 4 intermediate
colorspaces; ``cspace_convert`` automatically finds the optimal route
and applies all conversions in sequence:

This function also of course accepts arbitrary NumPy arrays, so
converting a whole image is just as easy as converting a single value.

Documentation:
  http://colorspacious.readthedocs.org/

Installation:
  ``pip install colorspacious``

Downloads:
  https://pypi.python.org/pypi/colorspacious/

Code and bug tracker:
  https://github.com/njsmith/colorspacious

Contact:
  Nathaniel J. Smith <njs@pobox.com>

Dependencies:
  * Python 2.6+, or 3.3+
  * NumPy

Developer dependencies (only needed for hacking on source):
  * nose: needed to run tests

License:
  MIT, see LICENSE.txt for details.

References for algorithms we implement:
  * Luo, M. R., Cui, G., & Li, C. (2006). Uniform colour spaces based on
    CIECAM02 colour appearance model. Color Research & Application, 31(4),
    320–330. doi:10.1002/col.20227
  * Machado, G. M., Oliveira, M. M., & Fernandes, L. A. (2009). A
    physiologically-based model for simulation of color vision
    deficiency. Visualization and Computer Graphics, IEEE Transactions on,
    15(6), 1291–1298. http://www.inf.ufrgs.br/~oliveira/pubs_files/CVD_Simulation/CVD_Simulation.html

Other Python packages with similar functionality that you might want
to check out as well or instead:

* ``colour``: http://colour-science.org/
* ``colormath``: http://python-colormath.readthedocs.org/
* ``ciecam02``: https://pypi.python.org/pypi/ciecam02/
* ``ColorPy``: http://markkness.net/colorpy/ColorPy.html


