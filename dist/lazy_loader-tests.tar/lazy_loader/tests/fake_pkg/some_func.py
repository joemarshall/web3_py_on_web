def some_func():
    """Function with same name as submodule."""
    pass
